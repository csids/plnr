library(testthat)
library(plnr)

test_check("plnr")
