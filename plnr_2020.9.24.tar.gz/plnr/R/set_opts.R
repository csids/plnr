#' set_opts
#' @param force_verbose Force verbose
#' @export
set_opts <- function(
                     force_verbose = FALSE) {
  config$force_verbose <- force_verbose
}
