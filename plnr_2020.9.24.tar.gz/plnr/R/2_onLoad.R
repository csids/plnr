.onLoad <- function(libname, pkgname) {
  set_config()

  invisible()
}
