# plnr 2020.5.11

- fn_name can now take package::function_name arguments

# plnr 2020.5.4

- is_run_directly function created, allowing the user to see if their code is being run directly or from within a function

# plnr 2020.4.3

- set_opts function created, allowing for force_verbose to be set package wide

# plnr 2020.2.20

- create_rmarkdown skeleton created

# plnr 2020.1.28

- parallel_possible variable when initializing new Plan
